char b()
{
  return 0;
}

