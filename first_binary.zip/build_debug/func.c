struct blah2;
struct blah
{
  int iii;
  struct blah2* b2;
};

struct Vec2i
{
  int x;
  int y;
  struct blah b;
};

char func(int x, int y)
{
  struct Vec2i pos;
  int val = (x + ((2 * y) / 3));
  if ((1 == 1))
  {
    return (1 == 1);
  }
  else if ((1 == 2))
  {
    return (1 == 2);
  }
  else
  {
    return (1 != 1);
  }
  return (((x == 1) && (1 == 1)) || (1 == 1));
}

