char b();
char func(int x, int y);
int main()
{
  (b)();
  int var;
  var = 1;
  int var2 = 2;
  char aa = (1 != 2);
  char notAa = (!aa);
  int negative = ((-var2) + 12);
  1;
  (func)(var, ((var2 + 3) - 1));
  return 0;
}

